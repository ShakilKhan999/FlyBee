package com.example.flybee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
