import 'package:flutter/material.dart';
const Color themeColorBlue = Color(0xFF565D91);
const Color logoblue = Color(0xFF032178);
const Color firstbuttoncolor = Color(0xFFF1BE6C);
const Color logogold = Color(0xFFfebe07);
const Color orangetextcol=Color(0xFFFF745C);
const Color acceptbutcol= Color(0xFF01B075);
